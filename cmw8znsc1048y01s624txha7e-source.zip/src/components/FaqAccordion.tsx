"use client";

import * as Accordion from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";

export type FaqItem = { question: string; answer: string };

export default function FaqAccordion({ items }: { items: FaqItem[] }) {
  return (
    <Accordion.Root type="single" collapsible className="divide-y divide-border overflow-hidden rounded-lg border border-border bg-card shadow-soft">
      {items.map((item, index) => (
        <Accordion.Item key={item.question} value={`faq-${index}`} className="group">
          <Accordion.Header>
            <Accordion.Trigger
              id={`faq-trigger-${index}`}
              className="flex w-full items-start gap-4 px-5 py-5 text-left transition-colors hover:bg-surface sm:px-7"
            >
              <span className="mt-0.5 font-heading text-sm font-bold text-primary tabular-nums">Q{index + 1}</span>
              <span className="flex-1 font-heading text-[15px] font-semibold leading-relaxed text-foreground sm:text-base">
                {item.question}
              </span>
              <ChevronDown
                aria-hidden
                className="mt-0.5 h-5 w-5 shrink-0 text-primary transition-transform duration-200 group-data-[state=open]:rotate-180"
              />
            </Accordion.Trigger>
          </Accordion.Header>
          <Accordion.Content className="overflow-hidden">
            <div className="px-5 pb-6 pl-[3.4rem] text-sm leading-[1.9] text-muted sm:px-7 sm:pl-[3.9rem]">
              <span id={`faq-answer-${index}`}>{item.answer}</span>
            </div>
          </Accordion.Content>
        </Accordion.Item>
      ))}
    </Accordion.Root>
  );
}
