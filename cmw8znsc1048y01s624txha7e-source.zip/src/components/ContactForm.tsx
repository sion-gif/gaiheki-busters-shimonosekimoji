"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(1, "お名前を入力してください").max(100),
  kana: z.string().max(100).optional(),
  tel: z
    .string()
    .min(1, "電話番号を入力してください")
    .max(30)
    .regex(/^[0-9\-+() ]{9,}$/, "電話番号の形式で入力してください"),
  email: z.string().email("メールアドレスの形式で入力してください").max(320),
  address: z.string().max(300).optional(),
  message: z.string().min(10, "ご相談内容を10文字以上で入力してください").max(5000),
  consent: z.literal(true, { message: "プライバシーポリシーへの同意が必要です" }),
  hp: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const fieldClass =
  "w-full rounded-md border border-border bg-background px-4 py-3 text-[15px] text-foreground shadow-soft transition-colors placeholder:text-muted/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25";
const labelClass = "mb-2 flex items-center gap-2 text-sm font-semibold text-foreground";
const errorClass = "mt-1.5 text-xs font-medium text-accent-strong";

export default function ContactForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    const form = formRef.current;
    setError(false);
    // Honeypot: a bot that filled the hidden field gets the success screen, nothing stored.
    if (data.hp) {
      setSubmitted(true);
      return;
    }
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, source: window.location.pathname }),
      });
      const result = await res.json().catch(() => ({}));
      if (!res.ok || result?.ok !== true) {
        setError(true);
        return;
      }
      const win = window as unknown as {
        noimosFormSuccess?: (form: HTMLFormElement) => void;
        noimosTrack?: (event: string) => void;
      };
      if (form) win.noimosFormSuccess?.(form);
      win.noimosTrack?.("goal:lead");
      setSubmitted(true);
    } catch {
      setError(true);
    }
  };

  if (submitted) {
    return (
      <div className="rounded-lg border border-primary/20 bg-primary-soft/60 p-8 text-center sm:p-10">
        <p id="form-success" className="font-heading text-xl font-bold text-primary">送信しました</p>
        <p className="mx-auto mt-3 max-w-md text-sm leading-[1.9] text-muted">
          内容を確認のうえ、担当（関門WORKS.）よりご連絡します。お急ぎの場合は
          <a href="tel:08029382832" className="mx-1 font-semibold text-primary underline underline-offset-2">
            080-2938-2832
          </a>
          へお電話ください（電話受付 9:00〜18:00）。
        </p>
        <p className="mt-4 text-xs text-muted">外壁の写真や図面は、お見積りの際にご確認させてください。</p>
      </div>
    );
  }

  return (
    <form ref={formRef} data-na-form="contact" onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className={labelClass}>
            お名前
            <span className="rounded-sm bg-accent/10 px-1.5 py-0.5 text-[10px] font-bold text-accent-strong">必須</span>
          </label>
          <input id="name" {...register("name")} className={fieldClass} placeholder="山田 太郎" autoComplete="name" />
          {errors.name && <p className={errorClass}>{errors.name.message}</p>}
        </div>
        <div>
          <label htmlFor="kana" className={labelClass}>
            フリガナ
            <span className="text-[10px] font-medium text-muted">任意</span>
          </label>
          <input id="kana" {...register("kana")} className={fieldClass} placeholder="ヤマダ タロウ" />
          {errors.kana && <p className={errorClass}>{errors.kana.message}</p>}
        </div>
        <div>
          <label htmlFor="tel" className={labelClass}>
            電話番号
            <span className="rounded-sm bg-accent/10 px-1.5 py-0.5 text-[10px] font-bold text-accent-strong">必須</span>
          </label>
          <input id="tel" type="tel" inputMode="tel" {...register("tel")} className={fieldClass} placeholder="090-0000-0000" autoComplete="tel" />
          {errors.tel && <p className={errorClass}>{errors.tel.message}</p>}
        </div>
        <div>
          <label htmlFor="email" className={labelClass}>
            メールアドレス
            <span className="rounded-sm bg-accent/10 px-1.5 py-0.5 text-[10px] font-bold text-accent-strong">必須</span>
          </label>
          <input id="email" type="email" inputMode="email" {...register("email")} className={fieldClass} placeholder="you@example.com" autoComplete="email" />
          {errors.email && <p className={errorClass}>{errors.email.message}</p>}
        </div>
      </div>

      <div>
        <label htmlFor="address" className={labelClass}>
          ご住所
          <span className="text-[10px] font-medium text-muted">任意</span>
        </label>
        <input id="address" {...register("address")} className={fieldClass} placeholder="山口県下関市〜" autoComplete="street-address" />
        {errors.address && <p className={errorClass}>{errors.address.message}</p>}
      </div>

      <div>
        <label htmlFor="message" className={labelClass}>
          ご相談内容
          <span className="rounded-sm bg-accent/10 px-1.5 py-0.5 text-[10px] font-bold text-accent-strong">必須</span>
        </label>
        <textarea
          id="message"
          rows={5}
          {...register("message")}
          className={fieldClass}
          placeholder="外壁の黒ずみやコケが気になっています。築12年の戸建てです。"
        />
        {errors.message && <p className={errorClass}>{errors.message.message}</p>}
        <p className="mt-2 text-xs text-muted">
          外壁の写真や図面は、お見積りの際にご確認させてください。
        </p>
      </div>

      {/* Honeypot — hidden from people, filled by bots. */}
      <input
        {...register("hp")}
        type="text"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        className="absolute left-[-9999px] h-0 w-0 opacity-0"
      />

      <div>
        <label htmlFor="consent" className="flex items-start gap-3 text-sm text-foreground">
          <input
            id="consent"
            type="checkbox"
            {...register("consent")}
            className="mt-1 h-4 w-4 shrink-0 rounded-sm border-border text-primary accent-primary"
          />
          <span>
            <Link href="/privacy" className="font-semibold text-primary underline underline-offset-2">
              プライバシーポリシー
            </Link>
            に同意します
            <span className="ml-2 rounded-sm bg-accent/10 px-1.5 py-0.5 text-[10px] font-bold text-accent-strong">必須</span>
          </span>
        </label>
        {errors.consent && <p id="consent-error" className={errorClass}>{errors.consent.message}</p>}
      </div>

      {error && (
        <p role="alert" className="rounded-md border border-accent/30 bg-accent/5 px-4 py-3 text-sm text-accent-strong">
          送信できませんでした。時間をおいてもう一度お試しいただくか、お電話（080-2938-2832）でご連絡ください。
        </p>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="flex w-full items-center justify-center gap-2 rounded-md bg-primary px-6 py-4 font-heading text-base font-bold text-primary-foreground shadow-soft transition-colors hover:bg-deep disabled:cursor-not-allowed disabled:opacity-60"
      >
        {isSubmitting ? "送信中…" : "この内容で無料見積りを依頼する"}
      </button>
      <p className="text-center text-xs text-muted">ご相談・お見積りは無料です。</p>
    </form>
  );
}
