import { authorPublicUrl, type ArticleAuthor } from "@/lib/articleAuthors";

/** Inherits site typography and colors. Provider biography is text, never HTML. */
export function ArticleAuthors({ authors = [] }: { authors?: ArticleAuthor[] }) {
  const named = authors.filter(author => author.name);
  if (!named.length) return null;
  return <div className="flex flex-col gap-4">
    {named.map(author => {
      const profileUrl = authorPublicUrl(author.profileUrl);
      const avatarUrl = authorPublicUrl(author.avatarUrl);
      return <div key={author.contentAuthorId} className="flex items-start gap-3">
        {avatarUrl && <img src={avatarUrl} alt="" width={48} height={48} loading="lazy"
          className="h-12 w-12 shrink-0 rounded-full object-cover" referrerPolicy="no-referrer" />}
        <div>
          <p className="font-medium">{profileUrl ? <a href={profileUrl} rel="author" className="underline underline-offset-4">{author.name}</a> : author.name}</p>
          {author.description && <p className="mt-1 whitespace-pre-line text-sm opacity-75">{author.description}</p>}
        </div>
      </div>;
    })}
  </div>;
}
