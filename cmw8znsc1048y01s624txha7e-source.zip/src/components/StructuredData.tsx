"use client";

import { usePathname } from "next/navigation";
import { SITE_URL, SITE_NAME, SITE_DESCRIPTION, SITE_LANG } from "@/lib/site";

// AI-discoverability baseline (GEO) — one JSON-LD @graph with Organization +
// WebSite + WebPage, shipped ON by default. This is the single home for the site
// @graph; enrich via the `geo` skill: add real `logo`/`sameAs` and type-specific
// nodes (Service, Product, FAQPage, Article…). Keep `inLanguage` matching the
// content. The owner's "JSON-LD structured data" toggle is enforced
// deterministically: turning it OFF injects NEXT_PUBLIC_SEO_JSONLD=off at build and
// this renders nothing (no AI edit needed).
function titleize(segment: string): string {
  return segment.replace(/[-_]+/g, " ").replace(/\b\w/g, (character) => character.toUpperCase());
}

export default function StructuredData() {
  const pathname = usePathname();
  if (process.env.NEXT_PUBLIC_SEO_JSONLD === "off") return null;
  if (!pathname) return null;

  const siteUrl = SITE_URL.replace(/\/+$/, "");
  const normalizedPath = pathname === "/" ? "/" : pathname.replace(/\/+$/, "");
  const pageUrl = normalizedPath === "/" ? `${siteUrl}/` : `${siteUrl}${normalizedPath}`;
  const lastSegment = normalizedPath.split("/").filter(Boolean).at(-1);
  const pageName = lastSegment ? `${titleize(lastSegment)} | ${SITE_NAME}` : SITE_NAME;
  const siteJsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${siteUrl}/#organization`,
        description: SITE_DESCRIPTION,
        name: SITE_NAME,
        url: `${siteUrl}/`,
      },
      {
        "@type": "WebSite",
        "@id": `${siteUrl}/#website`,
        description: SITE_DESCRIPTION,
        inLanguage: SITE_LANG,
        name: SITE_NAME,
        publisher: { "@id": `${siteUrl}/#organization` },
        url: `${siteUrl}/`,
      },
      {
        "@type": "WebPage",
        "@id": `${pageUrl}#webpage`,
        inLanguage: SITE_LANG,
        isPartOf: { "@id": `${siteUrl}/#website` },
        name: pageName,
        url: pageUrl,
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(siteJsonLd).replace(/</g, "\\u003c"),
      }}
    />
  );
}
