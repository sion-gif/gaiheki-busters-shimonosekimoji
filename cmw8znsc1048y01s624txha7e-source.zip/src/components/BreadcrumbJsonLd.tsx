"use client";

import { usePathname } from "next/navigation";
import { SITE_NAME, SITE_URL } from "@/lib/site";

// Deterministic BreadcrumbList JSON-LD (GEO) — shipped ON by default, derived from
// the current route's path segments (no AI needed). The owner's "Breadcrumbs
// structured data" toggle is enforced deterministically: turning it OFF injects
// NEXT_PUBLIC_SEO_BREADCRUMBS=off at build and this renders nothing. Enrich the
// per-crumb names via the `geo` skill only if the segment slug is a poor label.
function titleize(segment: string): string {
  return segment.replace(/[-_]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export default function BreadcrumbJsonLd() {
  const pathname = usePathname();
  if (process.env.NEXT_PUBLIC_SEO_BREADCRUMBS === "off") return null;
  if (!pathname) return null;

  const segments = pathname.split("/").filter(Boolean);
  if (segments.length === 0) return null; // the home page has no breadcrumb trail

  const itemListElement = [
    { "@type": "ListItem", position: 1, name: SITE_NAME, item: SITE_URL },
    ...segments.map((segment, i) => ({
      "@type": "ListItem",
      position: i + 2,
      name: titleize(segment),
      item: `${SITE_URL}/${segments.slice(0, i + 1).join("/")}`,
    })),
  ];

  const breadcrumbList = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement,
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(breadcrumbList).replace(/</g, "\\u003c"),
      }}
    />
  );
}
