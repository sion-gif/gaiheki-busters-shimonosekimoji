import Image from "next/image";
import Link from "next/link";
import type { AnchorHTMLAttributes, ReactNode } from "react";
import { BUSINESS } from "@/lib/business";
import { FOOTER_ITEMS, NAV_ITEMS, navItemsFor, resolveNavHref } from "@/lib/siteNav";

/**
 * Shared site chrome — the header, footer and mobile CTA bar mounted in
 * `src/app/layout.tsx` around every route, plus `<SiteLink>`, the ONLY way a
 * chrome link should be written (see src/lib/siteNav.ts for why: a path mount
 * serves this site on the owner's existing website, where a plain
 * `<Link href="/about">` leaks the visitor to a page of a different site).
 */

type SiteLinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href"> & {
  href: string;
  children: ReactNode;
};

export function SiteLink({ href, children, ...rest }: SiteLinkProps) {
  const resolved = resolveNavHref(href);
  if (!resolved) return null;
  if (resolved.kind === "internal") {
    return (
      <Link href={resolved.href} {...rest}>
        {children}
      </Link>
    );
  }
  const external = resolved.kind === "external" ? { target: "_blank", rel: "noopener noreferrer" } : {};
  return (
    <a href={resolved.href} {...external} {...rest}>
      {children}
    </a>
  );
}

export function SiteHeader() {
  const items = navItemsFor(NAV_ITEMS);
  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:h-[4.5rem] sm:px-8">
        <SiteLink href="/" aria-label={BUSINESS.storeName} className="flex shrink-0 items-center gap-2.5">
          <span className="relative block h-10 w-10 shrink-0 sm:h-11 sm:w-11">
            <Image
              src={BUSINESS.logo}
              alt=""
              fill
              sizes="48px"
              priority
              className="object-contain"
            />
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-heading text-[13px] font-extrabold tracking-tight text-primary sm:text-[15px]">
              {BUSINESS.brandName}
            </span>
            <span className="mt-1 text-[11px] font-semibold tracking-[0.06em] text-foreground/80">下関門司店</span>
          </span>
          <span className="hidden border-l border-border pl-3 text-[11px] leading-[1.45] text-muted xl:block">
            {BUSINESS.area[0]}
            <br />
            {BUSINESS.area[1]}
          </span>
        </SiteLink>

        <nav aria-label="メインメニュー" className="ml-auto hidden items-center gap-5 text-[13px] font-medium text-muted lg:flex">
          {items.map((item) => (
            <SiteLink key={item.href} href={item.href} className="transition-colors hover:text-primary">
              {item.label}
            </SiteLink>
          ))}
        </nav>

        <a
          href={BUSINESS.telHref}
          className="ml-auto flex shrink-0 items-center gap-2 rounded-full bg-primary px-3 py-2 text-left text-primary-foreground shadow-soft transition-colors hover:bg-deep sm:px-4 sm:py-2.5 lg:ml-4"
        >
          <svg viewBox="0 0 24 24" aria-hidden className="h-4 w-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="leading-tight">
            <span className="block text-[10px] font-normal opacity-80">無料相談</span>
            <span className="block whitespace-nowrap text-[12px] font-bold tracking-wide tabular-nums sm:text-[13px]">{BUSINESS.tel}</span>
          </span>
        </a>
      </div>

      <div className="border-t border-border/70 bg-surface/80 lg:hidden">
        <nav aria-label="ページ内メニュー" className="mx-auto flex max-w-6xl gap-4 overflow-x-auto px-4 py-2 text-xs text-muted [mask-image:linear-gradient(to_right,black_86%,transparent)] sm:px-8">
          {items.map((item) => (
            <SiteLink key={item.href} href={item.href} className="whitespace-nowrap py-1 transition-colors hover:text-primary">
              {item.label}
            </SiteLink>
          ))}
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const items = navItemsFor(FOOTER_ITEMS);
  return (
    <footer className="bg-deep text-deep-foreground">
      <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1.2fr]">
          <div>
            <p className="font-heading text-lg font-bold tracking-tight text-white">{BUSINESS.storeName}</p>
            <p className="mt-3 text-sm leading-relaxed text-deep-foreground/80">
              {BUSINESS.area[0]}・{BUSINESS.area[1]}の外壁洗浄。
              <br />
              足場を組まず、外壁の汚れだけを落とします。
            </p>
            <p className="mt-4 text-sm text-deep-foreground/80">運営：{BUSINESS.company}</p>
            <p className="text-sm text-deep-foreground/80">{BUSINESS.address}</p>
          </div>

          <nav aria-label="フッターメニュー" className="text-sm">
            <p className="mb-3 font-heading text-xs font-bold tracking-[0.18em] text-deep-foreground/60">MENU</p>
            <ul className="space-y-2">
              {items.map((item) => (
                <li key={item.href}>
                  <SiteLink href={item.href} className="text-deep-foreground/85 transition-colors hover:text-white">
                    {item.label}
                  </SiteLink>
                </li>
              ))}
            </ul>
          </nav>

          <div className="text-sm">
            <p className="mb-3 font-heading text-xs font-bold tracking-[0.18em] text-deep-foreground/60">CONTACT</p>
            <a href={BUSINESS.telHref} className="font-heading text-2xl font-bold tracking-tight text-white tabular-nums">
              {BUSINESS.tel}
            </a>
            <p className="mt-1 text-xs text-deep-foreground/70">電話受付 {BUSINESS.telHours}／{BUSINESS.closed}</p>
            <p className="mt-3 text-xs text-deep-foreground/70">
              営業時間 {BUSINESS.hours}（{BUSINESS.closed}）
            </p>
            <div className="mt-4 flex flex-wrap gap-3 text-xs">
              <SiteLink
                href={BUSINESS.instagram}
                className="rounded-full border border-white/25 px-3 py-1.5 transition-colors hover:border-white/60"
              >
                Instagram
              </SiteLink>
              <SiteLink
                href={BUSINESS.tiktok}
                className="rounded-full border border-white/25 px-3 py-1.5 transition-colors hover:border-white/60"
              >
                TikTok
              </SiteLink>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-white/15 pt-6 text-[11px] leading-relaxed text-deep-foreground/60">
          <p>
            {BUSINESS.brandName}は、{BUSINESS.area[0]}・{BUSINESS.area[1]}の外壁洗浄サービスです。「ガイヘキ洗浄バスターズ®」は、
            {BUSINESS.parentCompany}の登録商標です。
          </p>
          <p className="mt-2">
            © {new Date().getFullYear()} {BUSINESS.company}
          </p>
        </div>
      </div>
      {/* Mobile sticky CTA: keeps the one action that matters (a free estimate) one tap away. */}
      <div className="h-16 lg:hidden" aria-hidden />
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 px-3 pb-[calc(0.5rem+env(safe-area-inset-bottom))] pt-2 backdrop-blur lg:hidden">
        <div className="grid grid-cols-2 gap-2">
          <a
            href={BUSINESS.telHref}
            className="flex flex-col items-center justify-center rounded-md bg-primary px-2 py-2.5 text-[11px] font-semibold text-primary-foreground"
          >
            <span className="text-[9px] font-normal opacity-85">電話で相談</span>
            <span className="whitespace-nowrap text-[12px]">080-2938-2832</span>
          </a>
          <SiteLink
            href="/#contact"
            className="flex flex-col items-center justify-center rounded-md border border-primary/25 bg-primary-soft px-2 py-2.5 text-[12px] font-bold text-primary"
          >
            <span className="text-[9px] font-normal text-primary/80">フォームで</span>
            無料見積り
          </SiteLink>
        </div>
      </div>
    </footer>
  );
}
