import "server-only";

const endpoint = process.env.NOIMOS_WEBSITE_CRM_FORM_ENDPOINT;
const formId = process.env.NOIMOS_WEBSITE_CRM_FORM_ID;
// CRM lead sync is enabled only when both are injected (Manage → CRM).
const crmEnabled = Boolean(endpoint && formId);

/**
 * Forward a validated lead to the workspace CRM. Call AFTER the DB insert, from
 * trusted server code only. No-op (returns false) when CRM sync is off. Never
 * throws — a CRM failure must never break lead capture.
 */
export async function forwardLeadToCrm(
  data: Record<string, unknown>,
  origin?: string | null,
): Promise<boolean> {
  if (!crmEnabled) return false;
  try {
    const res = await fetch(endpoint!, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(origin ? { Origin: origin } : {}),
      },
      body: JSON.stringify({ formId, data }),
      cache: "no-store",
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return false;
    const result: unknown = await res.json();
    return typeof result === "object" && result !== null && "ok" in result && result.ok === true;
  } catch {
    return false;
  }
}
