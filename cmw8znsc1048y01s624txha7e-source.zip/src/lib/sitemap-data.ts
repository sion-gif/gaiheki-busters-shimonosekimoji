import { fetchSiteBlogGroups } from "@/lib/articles";
import { discoveryPages, discoveryUrl } from "@/lib/discovery";
import { partitionSitemap, type ClassifiedSitemapEntry } from "@/lib/sitemaps";

/** One source for a flat sitemap or native language/content partitions. */
async function sitemapRecords(): Promise<ClassifiedSitemapEntry[]> {
  const groups = await fetchSiteBlogGroups({ complete: true });
  const pages = discoveryPages();
  const locales = new Map(pages.map(page => [page.url,
    Object.entries(page.languages).find(([language, href]) => language !== "x-default" && href === page.url)?.[0] ?? "default",
  ]));
  const localeOf = (url: string) => locales.get(url) ?? "default";
  const records: ClassifiedSitemapEntry[] = pages.map(page => ({
    locale: localeOf(page.url), section: groups.some(group => discoveryUrl(group.basePath) === page.url) ? "blog" : "pages",
    entry: { url: page.url, ...(Object.keys(page.languages).length ? { alternates: { languages: page.languages } } : {}) },
  }));
  for (const group of groups) {
    const index = discoveryUrl(group.basePath);
    const locale = index ? localeOf(index) : "default";
    if (index && group.articles.length) records.push({ entry: { url: index }, locale, section: "blog" });
    for (const article of group.articles) {
      const url = discoveryUrl(article.link);
      if (!url) continue;
      const date = article.updatedAt;
      records.push({ locale, section: "blog", entry: { url, ...(date && Number.isFinite(Date.parse(date)) ? { lastModified: date } : {}) } });
    }
  }
  // Preserve the first static record's real hreflang when a CMS index overlaps it.
  const seen = new Set<string>();
  return records.filter(record => { if (seen.has(record.entry.url)) return false; seen.add(record.entry.url); return true; });
}

export async function getSitemapEntries() { return (await sitemapRecords()).map(record => record.entry); }
export async function getSitemapParts() { return partitionSitemap(await sitemapRecords()); }
