/** DOM adapter for source-observed overlays in a mechanically imported page.
 * Mark the actual outer overlay and its background in editable JSX first.
 * Do not guess ownership from generic Close labels or remove inert globally.
 * Recreate/dispose this controller when the owning route mounts/unmounts.
 */
export interface ObservedOverlay {
  name: string;
  root: HTMLElement;
  backgrounds: readonly HTMLElement[];
  initiallyOpen: boolean;
  displayWhenOpen: string;
  onOpenChange?: (open: boolean) => void;
}

export function createObservedOverlayController(overlays: readonly ObservedOverlay[]) {
  const roots = new Set(overlays.map(item => item.root));
  if (roots.size !== overlays.length || new Set(overlays.map(item => item.name)).size !== overlays.length) {
    throw new Error("Overlay roots and names must be unique");
  }
  for (const item of overlays) {
    if (!item.displayWhenOpen || item.displayWhenOpen === "none" || item.root.ownerDocument !== document ||
      item.backgrounds.some(background => roots.has(background) || background.contains(item.root))) {
      throw new Error(`Overlay ${item.name} needs a visible display and separate background roots`);
    }
  }
  const elements = new Set([...roots, ...overlays.flatMap(item => [...item.backgrounds])]);
  const original = [...elements].map(element => ({ element,
    display: element.style.getPropertyValue("display"), priority: element.style.getPropertyPriority("display"),
    inert: element.hasAttribute("inert"), hidden: element.hidden, ariaHidden: element.getAttribute("aria-hidden"),
  }));
  const bodyOverflow = document.body.style.overflow;
  const bodyOverflowPriority = document.body.style.getPropertyPriority("overflow");
  const opened: ObservedOverlay[] = [];
  const returnFocus = new Map<string, HTMLElement>();
  let disposed = false;
  let transition = 0;
  const focusable = (root: HTMLElement) => Array.from(root.querySelectorAll<HTMLElement>(
    'button,a[href],input,select,textarea,[tabindex]',
  )).filter(element => !element.matches(':disabled,[tabindex="-1"]') && !element.closest('[inert],[hidden]') &&
    element.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true }) && element.getClientRects().length > 0);
  const sync = () => {
    for (const item of overlays) {
      const open = opened.includes(item);
      item.root.style.setProperty("display", open ? item.displayWhenOpen : "none", "important");
      item.root.hidden = !open;
      const active = open && opened.at(-1) === item;
      item.root.inert = !active;
      if (active) item.root.removeAttribute("aria-hidden");
      else item.root.setAttribute("aria-hidden", "true");
    }
    for (const background of new Set(overlays.flatMap(item => [...item.backgrounds]))) {
      const blocked = opened.some(item => item.backgrounds.includes(background));
      background.inert = blocked;
      if (blocked) background.setAttribute("aria-hidden", "true");
      else background.removeAttribute("aria-hidden");
    }
    if (opened.length) document.body.style.setProperty("overflow", "hidden", "important");
    else if (bodyOverflow) document.body.style.setProperty("overflow", bodyOverflow, bodyOverflowPriority);
    else document.body.style.removeProperty("overflow");
  };
  const setOpen = (name: string, open: boolean, opener?: HTMLElement) => {
    if (disposed) return;
    const item = overlays.find(candidate => candidate.name === name);
    if (!item) throw new Error(`Unknown observed overlay: ${name}`);
    const index = opened.indexOf(item);
    if (open === (index >= 0)) return;
    const currentTransition = ++transition;
    if (open) {
      const previousFocus = opener ?? (document.activeElement instanceof HTMLElement ? document.activeElement : undefined);
      if (previousFocus && !item.root.contains(previousFocus)) returnFocus.set(name, previousFocus);
      opened.push(item);
    } else {
      opened.splice(index, 1);
    }
    sync();
    // Captured panels may also be hidden by opacity/visibility. Let the adapter
    // restore those styles (or the opener) before choosing a focus target.
    item.onOpenChange?.(open);
    // A callback may hand off to another overlay or unmount this controller.
    // In that case the newer transition owns focus.
    if (disposed || currentTransition !== transition) return;
    if (open) focusable(item.root)[0]?.focus();
    else {
      const previousFocus = returnFocus.get(name);
      const top = opened.at(-1);
      if (previousFocus?.isConnected && !previousFocus.closest("[inert]") && (!top || top.root.contains(previousFocus))) previousFocus.focus();
      else if (top) focusable(top.root)[0]?.focus();
      returnFocus.delete(name);
    }
  };
  const closeFrom = (control: Element): boolean => {
    for (let node: Element | null = control; node; node = node.parentElement) {
      const item = overlays.find(candidate => candidate.root === node);
      if (item) { setOpen(item.name, false); return true; }
    }
    return false;
  };
  const onKeyDown = (event: KeyboardEvent) => {
    const top = opened.at(-1);
    if (!top) return;
    if (event.key === "Escape") {
      event.preventDefault(); setOpen(top.name, false);
    } else if (event.key === "Tab") {
      const candidates = focusable(top.root);
      const first = candidates[0];
      const last = candidates.at(-1);
      if (!first || !last) { event.preventDefault(); return; }
      if (!top.root.contains(document.activeElement) || (event.shiftKey ? document.activeElement === first : document.activeElement === last)) {
        event.preventDefault(); (event.shiftKey ? last : first).focus();
      }
    }
  };
  for (const item of overlays) if (item.initiallyOpen) opened.push(item);
  sync();
  document.addEventListener("keydown", onKeyDown);
  return {
    setOpen, closeFrom,
    isOpen: (name: string) => opened.some(item => item.name === name),
    dispose() {
      if (disposed) return;
      disposed = true;
      document.removeEventListener("keydown", onKeyDown);
      for (const state of original) {
        if (state.display) state.element.style.setProperty("display", state.display, state.priority);
        else state.element.style.removeProperty("display");
        state.element.inert = state.inert;
        state.element.hidden = state.hidden;
        if (state.ariaHidden === null) state.element.removeAttribute("aria-hidden");
        else state.element.setAttribute("aria-hidden", state.ariaHidden);
      }
      if (bodyOverflow) document.body.style.setProperty("overflow", bodyOverflow, bodyOverflowPriority);
      else document.body.style.removeProperty("overflow");
    },
  };
}
