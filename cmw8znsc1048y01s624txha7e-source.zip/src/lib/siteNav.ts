import { SITE_URL } from "@/lib/site";

/**
 * Site navigation — the ONE list the header and footer render from, plus the
 * path-mount rules every internal link in shared chrome must follow.
 *
 * A path mount (rpi/website-path-mount) deploys this site at ONE path on a
 * website the owner already runs. There, `NEXT_PUBLIC_SITE_URL` is THEIR origin
 * and every path outside the mounted prefix belongs to THEIR existing site — so
 * keep every chrome link on these helpers and `<SiteLink>`.
 */

export interface NavItem {
  label: string;
  /** Root-relative route (`/pricing`, `/#price`) or an absolute external URL. */
  href: string;
}

/**
 * Top-level navigation. This is a one-page site, so each item is a root-absolute
 * home-page section (`/#price`) rather than a bare `#price` — a bare fragment in
 * shared chrome resolves against whatever route the visitor is on.
 */
export const NAV_ITEMS: NavItem[] = [
  { label: "外壁洗浄とは", href: "/#about" },
  { label: "選ばれる理由", href: "/#reason" },
  { label: "料金", href: "/#price" },
  { label: "施工の流れ", href: "/#flow" },
  { label: "対応エリア・店舗", href: "/#shop" },
  { label: "よくある質問", href: "/#faq" },
];

/** Footer-only links (legal pages etc.). Same rules as NAV_ITEMS. */
export const FOOTER_ITEMS: NavItem[] = [
  { label: "プライバシーポリシー", href: "/privacy" },
  { label: "ブランドサイト", href: "https://gaiheki-busters.com" },
];

/** True in a path-mount build. Inlined at build time (NEXT_PUBLIC_*). */
export const IS_MOUNT =
  process.env.NEXT_PUBLIC_BLOG_MOUNT === "1" || process.env.NEXT_PUBLIC_PATH_MOUNT === "1";

/** The mounted prefix (`/blog`) in a mount build; "" otherwise. */
export const MOUNT_PATH = (
  process.env.NEXT_PUBLIC_MOUNT_PATH_PREFIX ??
  process.env.NEXT_PUBLIC_BLOG_BASE_PATH ??
  ""
).replace(/\/+$/, "");

function isAbsolute(href: string): boolean {
  return /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(href);
}

/** Does this href stay inside the mounted path? (Only meaningful on a mount.) */
export function isOnMount(href: string): boolean {
  if (!MOUNT_PATH) return false;
  return (
    href === MOUNT_PATH ||
    href.startsWith(`${MOUNT_PATH}/`) ||
    href.startsWith(`${MOUNT_PATH}?`) ||
    href.startsWith(`${MOUNT_PATH}#`)
  );
}

export interface ResolvedNavHref {
  href: string;
  /**
   * `internal` → `<Link>`; `external` → `<a target="_blank">` (another
   * website); `site-root` → a plain `<a>` to the customer's own root on a
   * mount — same website from the visitor's point of view, so no new tab.
   */
  kind: "internal" | "external" | "site-root";
}

/**
 * Where a chrome link actually goes. `null` means "do not render this link at
 * all" — an off-mount route on a mount.
 */
export function resolveNavHref(href: string): ResolvedNavHref | null {
  if (isAbsolute(href)) return { href, kind: "external" };
  if (!IS_MOUNT) return { href, kind: "internal" };
  if (href === "/" || href.startsWith("/#") || href.startsWith("/?")) {
    // The brand/home link keeps working on a mount: it goes to the customer's
    // own root (SITE_URL is their origin there). A home-page section anchor
    // has no home page to scroll on a mount, so it becomes the root as well.
    return { href: `${SITE_URL}/`, kind: "site-root" };
  }
  if (!href.startsWith("/")) return { href, kind: "internal" }; // relative / query-only
  return isOnMount(href) ? { href, kind: "internal" } : null;
}

/** The nav items that may render in the current build (all of them off a mount). */
export function navItemsFor<T extends NavItem>(items: readonly T[]): T[] {
  return items.filter((item) => resolveNavHref(item.href) !== null);
}

/** The brand link target: `/` normally, the customer's root on a mount. */
export function homeHref(): string {
  return resolveNavHref("/")?.href ?? "/";
}
