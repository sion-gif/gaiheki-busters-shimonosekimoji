/**
 * 店舗の一次情報（.agents/source-facts.md に基づく）。
 * 電話番号・住所・営業時間などの事実はここだけを参照し、ページ側で書き換えない。
 */
export const BUSINESS = {
  storeName: "ガイヘキ洗浄バスターズ 下関門司店",
  brandName: "ガイヘキ洗浄バスターズ",
  company: "関門WORKS.",
  address: "山口県下関市彦島江の浦町9-8-22",
  area: ["山口県下関市", "福岡県北九州市門司区"],
  tel: "080-2938-2832",
  telHref: "tel:08029382832",
  telHours: "9:00〜18:00",
  hours: "8:00〜19:00",
  closed: "不定休",
  brandSite: "https://gaiheki-busters.com",
  storePage: "https://gaiheki-busters.com/shop/shimonosekimoji",
  instagram: "https://www.instagram.com/gaihekisenjou/",
  tiktok: "https://www.tiktok.com/@gaihekisenjou.simonoseki",
  hqTel: "0120-959-936",
  hqHours: "9:00〜17:00",
  parentCompany: "PLジャパン株式会社",
  logo: "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/brand-logo/5f728b01ac503e838c48c40ff3aa1a1d.png",
} as const;

export const IMAGES = {
  // オーナー提供の実施工写真（ヒーローのメイン写真）
  hero: "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/cmw8znsc1048y01s624txha7e/26eab9bacc26ea20.webp",
  moss: "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/cmw8znsc1048y01s624txha7e/3ad3147ab07e1228.webp",
  rainStreak:
    "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/cmw8znsc1048y01s624txha7e/7ea05cfdf8645abb.webp",
  brush:
    "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/cmw8znsc1048y01s624txha7e/7e5d279277cc573d.webp",
  // オーナー提供の実写真：左が洗浄前・右が洗浄後の比較（矢印付き）
  beforeAfter:
    "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/cmw8znsc1048y01s624txha7e/32d3a5fff5a033cc.jpg",
  town: "https://storage.googleapis.com/noimosai-webpage-assets-prod/cmw8rutlc00ez01s6c604bo7v/cmw8znsc1048y01s624txha7e/610f0255a437c398.webp",
} as const;
