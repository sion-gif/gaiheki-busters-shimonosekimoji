/**
 * Published blog articles for this site, fetched live from the Noimos CMS.
 *
 * The GEO baseline — `sitemap.ts` and `llms.txt/route.ts` — reads published posts
 * without a manual sitemap edit or rebuild. Cached routes revalidate on access;
 * publication does not synchronously regenerate every output. Gated on the SEO auto-update
 * toggle (`NEXT_PUBLIC_SEO_AUTO_UPDATE`, default off). Returns `[]` when the blog is
 * off or unwired (`NEXT_PUBLIC_CMS_API_BASE_URL` / `NEXT_PUBLIC_WEBSITE_ID` are
 * injected only while the blog is enabled), so a blog-less site ships just its
 * static pages. Default reads are bounded/best-effort; complete sitemap reads
 * reject failed or truncated inventories instead of claiming they are complete.
 *
 * Intentionally self-contained — NOT the blog skill's `src/lib/blog.ts`, which is
 * scaffolded on demand — so the always-present SEO baseline never depends on the
 * blog pages having been built.
 */
import type { ArticleAuthor } from "./articleAuthors";

export interface SiteArticle {
  authors?: ArticleAuthor[];
  title: string;
  /** Base-path-relative, e.g. "/blog/my-post". */
  link: string;
  /** Short summary (present in the list response) — used by llms-full.txt. */
  excerpt?: string | null;
  publishedAt?: string | null;
  updatedAt?: string | null;
  createdAt?: string;
}

export interface SiteBlogGroup {
  id: string | null;
  name: string;
  basePath: string;
  description: string | null;
  articles: SiteArticle[];
}

function discoveryEnabled(): boolean {
  return process.env.NEXT_PUBLIC_SEO_AUTO_UPDATE === "1"
    || process.env.NEXT_PUBLIC_BLOG_MOUNT === "1"
    || process.env.NEXT_PUBLIC_PATH_MOUNT === "1";
}

/** All configured blogs owned by this artifact; article reads remain scoped. */
export async function fetchSiteBlogGroups(options: { complete?: boolean } = {}): Promise<SiteBlogGroup[]> {
  const base = process.env.NEXT_PUBLIC_CMS_API_BASE_URL;
  const websiteId = process.env.NEXT_PUBLIC_WEBSITE_ID;
  if (!base || !websiteId || !discoveryEnabled()) return [];
  const mounted = process.env.NEXT_PUBLIC_PATH_MOUNT === "1" || process.env.NEXT_PUBLIC_BLOG_MOUNT === "1";
  const scope = (process.env.NEXT_PUBLIC_PATH_MOUNT === "1"
    ? process.env.NEXT_PUBLIC_MOUNT_PATH_PREFIX : process.env.NEXT_PUBLIC_BLOG_BASE_PATH)?.replace(/\/+$/, "");
  if (mounted && !scope) return [];
  const variant = process.env.BLOG_VARIANT || "prod";
  const token = process.env.BLOG_PREVIEW_TOKEN;
  try {
    const response = await fetch(`${base}/cms-api/website/${websiteId}/collections?variant=${variant}`, {
      headers: token ? { "x-wb-preview-token": token } : undefined,
      next: { revalidate: 60 }, signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) { if (options.complete) throw new Error("CMS destinations could not be read completely."); return []; }
    const data = await response.json() as { collections?: Omit<SiteBlogGroup, "articles">[] };
    if (!Array.isArray(data.collections)) { if (options.complete) throw new Error("CMS destinations response is invalid."); return []; }
    const groups = data.collections.filter(group => !mounted || group.basePath === scope || group.basePath.startsWith(`${scope}/`));
    return await Promise.all(groups.map(async group => ({
      ...group,
      articles: (await fetchSiteArticles(group.id ?? "", options)).filter(article => article.link.startsWith(`${group.basePath.replace(/\/+$/, "")}/`)),
    })));
  } catch (error) {
    if (options.complete) throw error;
    return [];
  }
}

// Omission deliberately means the legacy default blog, never all destinations.
// The generated site's discovery layer selects the collections it serves.
export async function fetchSiteArticles(collectionId?: string, options: { complete?: boolean } = {}): Promise<SiteArticle[]> {
  const base = process.env.NEXT_PUBLIC_CMS_API_BASE_URL;
  const websiteId = process.env.NEXT_PUBLIC_WEBSITE_ID;
  if (!base || !websiteId) return [];
  // Auto-update gate (SEO tab): only when ON do the discovery files (sitemap /
  // llms.txt / llms-full.txt) live-list published articles. OFF (or unset by an
  // older build) freezes them to the static/core pages.
  // A path-mount artifact is exempt: its sitemap has no static/core pages to
  // freeze to (it lists only the blog), so honoring the toggle there would ship
  // an EMPTY sitemap to the URL the owner submits to Search Console rather than
  // a frozen one. The toggle keeps its meaning on the normal site artifact.
  if (!discoveryEnabled()) return [];
  const variant = process.env.BLOG_VARIANT || "prod";
  const token = process.env.BLOG_PREVIEW_TOKEN;
  const headers = token ? { "x-wb-preview-token": token } : undefined;

  const out: SiteArticle[] = [];
  let finished = false;
  const collection = collectionId !== undefined ? `&collection=${encodeURIComponent(collectionId)}` : "";
  try {
    // Page through the cms-api (100/page cap). Complete reads must prove they
    // reached the end; larger inventories need range/cursor-backed partitions.
    for (let page = 1; page <= 20; page++) {
      const res = await fetch(
        `${base}/cms-api/website/${websiteId}/articles?page=${page}&limit=100&variant=${variant}${collection}`,
        // Timeout cap: this runs during `next build` prerender (sitemap/rss) —
        // a slow CMS response must fail bounded complete reads, while ordinary
        // readers can keep their best-effort result.
        // Match the cms-api's 60s cache policy. The two cache layers can lag;
        // revalidation happens on access, not on a fixed publication deadline.
        { headers, next: { revalidate: 60 }, signal: AbortSignal.timeout(5000) },
      );
      if (!res.ok) { if (options.complete) throw new Error("CMS articles could not be read completely."); break; }
      const data = (await res.json()) as { articles?: SiteArticle[]; total?: number };
      const batch = Array.isArray(data.articles) ? data.articles : [];
      if (options.complete && !Array.isArray(data.articles)) throw new Error("CMS article response is invalid.");
      out.push(...batch);
      if (options.complete && batch.length < 100 && data.total !== undefined && out.length < data.total) {
        throw new Error("CMS articles ended before the reported total; inventory is incomplete.");
      }
      if (batch.length < 100 || (data.total !== undefined && out.length >= data.total)) { finished = true; break; }
      if (!options.complete && data.total === undefined) break;
    }
  } catch (error) {
    if (options.complete) throw error;
    // best-effort — the SEO files still ship their static pages
  }
  if (options.complete && !finished) throw new Error("CMS inventory exceeds this bounded reader; provide native range/cursor sitemap partitions instead of truncating articles.");
  return out;
}
