/** Public CMS attribution. Keep optional for sites serving older cache entries. */
export interface ArticleAuthor {
  contentAuthorId: string;
  name: string | null;
  description: string | null;
  avatarUrl: string | null;
  profileUrl: string | null;
}

export function authorPublicUrl(value: string | null | undefined): string | undefined {
  if (!value) return undefined;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : undefined;
  } catch { return undefined; }
}

export function articleAuthorJsonLd(authors: readonly ArticleAuthor[] = []) {
  return authors.flatMap(author => author.name ? [{
    "@type": "Person" as const,
    name: author.name,
    ...(authorPublicUrl(author.profileUrl) ? { url: authorPublicUrl(author.profileUrl) } : {}),
    ...(authorPublicUrl(author.avatarUrl) ? { image: authorPublicUrl(author.avatarUrl) } : {}),
  }] : []);
}
