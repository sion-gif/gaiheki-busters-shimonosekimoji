import type { MetadataRoute } from "next";

export type SitemapEntry = MetadataRoute.Sitemap[number];
export type ClassifiedSitemapEntry = { entry: SitemapEntry; section: string; locale: string };
export type SitemapPart = { id: string; entries: SitemapEntry[] };

// Leave room below the protocol's 50,000 URLs / 50 MiB limits, including hreflang.
const MAX_PART_URLS = 5_000;
const MAX_PART_BYTES = 40 * 1024 * 1024;
const encoder = new TextEncoder();

function byteBudget(entry: SitemapEntry): number {
  // An upper bound for Next's XML serialization (resolveSitemap), which writes each
  // value unescaped: the JSON encoding covers every value's UTF-8 bytes, plus each
  // element's fixed tags. Never measure string.length as bytes.
  return encoder.encode(JSON.stringify(entry)).byteLength + 256
    + Object.keys(entry.alternates?.languages ?? {}).length * 64
    + (entry.images?.length ?? 0) * 64 + (entry.videos?.length ?? 0) * 1024;
}

export function singleSitemap(entries: MetadataRoute.Sitemap): MetadataRoute.Sitemap {
  if (entries.length > 50_000 || entries.reduce((bytes, entry) => bytes + byteBudget(entry), 1024) > MAX_PART_BYTES) {
    throw new Error("This sitemap needs partitioning. Follow the GEO skill's native generateSitemaps + root index recipe; do not truncate URLs.");
  }
  return entries;
}

/** Partition real URL records by meaningful section/language, then by bounded size. */
export function partitionSitemap(records: readonly ClassifiedSitemapEntry[], limits = { urls: MAX_PART_URLS, bytes: MAX_PART_BYTES }): SitemapPart[] {
  if (!Number.isInteger(limits.urls) || limits.urls < 1 || limits.urls > 50_000 || limits.bytes < 4096 || limits.bytes > MAX_PART_BYTES) {
    throw new Error("Invalid sitemap partition limits.");
  }
  const groups = new Map<string, SitemapEntry[]>();
  const seen = new Set<string>();
  for (const { entry, section, locale } of records) {
    if (!/^[a-z][a-z0-9-]*$/i.test(section) || !/^[a-z][a-z0-9-]*$/i.test(locale)) throw new Error("Invalid sitemap section or language.");
    if (seen.has(entry.url)) continue;
    seen.add(entry.url);
    const key = `${section}-${locale}`;
    const group = groups.get(key) ?? [];
    group.push(entry); groups.set(key, group);
  }
  const parts: SitemapPart[] = [];
  for (const [key, group] of [...groups].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) {
    group.sort((a, b) => a.url < b.url ? -1 : a.url > b.url ? 1 : 0);
    let entries: SitemapEntry[] = [], bytes = 1024, number = 1;
    for (const entry of group) {
      const size = byteBudget(entry);
      if (size + 1024 > limits.bytes) throw new Error("One sitemap entry exceeds the XML budget; correct its URL/alternate data.");
      if (entries.length && (entries.length >= limits.urls || bytes + size > limits.bytes)) {
        parts.push({ id: `${key}-${number++}`, entries }); entries = []; bytes = 1024;
      }
      entries.push(entry); bytes += size;
    }
    if (entries.length) parts.push({ id: `${key}-${number}`, entries });
  }
  if (parts.length > 50_000) throw new Error("The sitemap index exceeds 50,000 child sitemaps.");
  return parts;
}

const xml = (value: string) => value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[character] ?? character);

/** Public child URLs share the inventory's directory scope; Next rewrites serve their XML. */
export function sitemapIndexXml(parts: readonly SitemapPart[], origin: string, prefix = ""): string {
  const rows = parts.map(part => `  <sitemap>\n    <loc>${xml(new URL(`${prefix}/sitemap-${part.id}.xml`, origin).href)}</loc>\n  </sitemap>`);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${rows.join("\n")}\n</sitemapindex>\n`;
}
