import { SITE_URL } from "@/lib/site";
import { NOIMOS_PAGES } from "@/lib/noimosRoutes";

export const singleLine = (value: string) => value.replace(/\s+/g, " ").trim();
export const linkTitle = (value: string) => singleLine(value).replace(/[\[\]\\]/g, "").slice(0, 180);

export function discoveryPrefix(): string {
  const prefix = process.env.NEXT_PUBLIC_PATH_MOUNT === "1" ? process.env.NEXT_PUBLIC_MOUNT_PATH_PREFIX
    : process.env.NEXT_PUBLIC_BLOG_MOUNT === "1" ? process.env.NEXT_PUBLIC_BLOG_BASE_PATH : "";
  return prefix?.replace(/\/+$/, "") ?? "";
}

/** Only paths this artifact serves; URL() also percent-encodes non-ASCII slugs. */
export function discoveryUrl(route: string): string | null {
  if (!route.startsWith("/") || route.startsWith("//") || /[\[\]#\r\n\\]/.test(route)) return null;
  const prefix = discoveryPrefix();
  const pathname = route.split("?")[0];
  if (prefix && pathname !== prefix && !pathname.startsWith(prefix + "/")) return null;
  if ((process.env.NEXT_PUBLIC_PATH_MOUNT === "1" || process.env.NEXT_PUBLIC_BLOG_MOUNT === "1") && !prefix) return null;
  const url = new URL(`${SITE_URL}${route}`);
  const owned = prefix ? new URL(`${SITE_URL}${prefix}`).pathname : "";
  if (owned && url.pathname !== owned && !url.pathname.startsWith(owned + "/")) return null;
  return url.href;
}

/** All discovery surfaces share the generated, indexable page records. */
export function discoveryPages() {
  const seen = new Set<string>();
  return NOIMOS_PAGES.flatMap(page => {
    const url = discoveryUrl(page.route);
    if (!url || seen.has(url)) return [];
    if (page.canonical && page.canonical !== "." && page.canonical !== "./"
        && new URL(page.canonical, SITE_URL + "/").href !== url) return [];
    seen.add(url);
    const languages = Object.fromEntries(Object.entries(page.languages ?? {}).flatMap(([locale, route]) => {
      const href = discoveryUrl(route);
      return href ? [[locale, href]] : [];
    }));
    return [{ ...page, url, languages }];
  });
}

export function markdownUrl(url: string): string {
  return url.replaceAll("(", "%28").replaceAll(")", "%29");
}
