import "server-only";

const apiUrl = process.env.NOIMOS_WEBSITE_API_URL;
const websiteId = process.env.NOIMOS_WEBSITE_ID;
const token = process.env.NOIMOS_WEBSITE_EMAIL_TOKEN;
// Email is enabled only when all three are injected (owner turned it on in Manage).
const emailEnabled = Boolean(apiUrl && websiteId && token);

type EmailBody = { subject: string; html: string; replyTo?: string };

async function gatewayPost(path: string, body: unknown): Promise<Response | null> {
  if (!emailEnabled) return null;
  return fetch(`${apiUrl}/api/public/website/${websiteId}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-noimos-website-token": token! },
    body: JSON.stringify(body),
    cache: "no-store",
  });
}

/** Notify the site owner. Recipient is the owner address configured in Manage. */
export async function sendOwnerNotification(body: EmailBody): Promise<boolean> {
  const res = await gatewayPost("/email/send", { kind: "notify", ...body });
  return Boolean(res?.ok);
}

/**
 * Send a confirmation to a visitor. `to` MUST be an address this request already
 * validated — never a raw value forwarded from an untrusted source.
 */
export async function sendVisitorAutoresponder(to: string, body: EmailBody): Promise<boolean> {
  const granted = await gatewayPost("/email/grant", { to });
  if (!granted?.ok) return false;
  const { grant } = (await granted.json().catch(() => ({}))) as { grant?: string };
  if (!grant) return false;
  const res = await gatewayPost("/email/send", { kind: "autoresponder", to, grant, ...body });
  return Boolean(res?.ok);
}
