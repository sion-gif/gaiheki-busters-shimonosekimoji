// GENERATED — do not edit by hand.
//
// Public static pages, derived from App Router files and literal metadata by
// siteRoutesService before builds. Redirects, retired pages and noindex pages
// are excluded; sitemap and LLM indices share these records.
//
// It is a TS module rather than a JSON file read at runtime on purpose: the
// sitemap route can execute on the Cloudflare Worker, where `node:fs` is not
// available, so the list must be bundled at build time.
export const NOIMOS_ROUTES: string[] = ["/"];
export type NoimosPage = { route: string; title?: string; description?: string; canonical?: string; languages?: Record<string, string> };
export const NOIMOS_PAGES: NoimosPage[] = [{ route: "/" }];
export const NOIMOS_DISCOVERY = { sitemap: true, llms: true };
export const NOIMOS_FILE_ROUTES: string[] = ["/robots.txt", "/sitemap.xml", "/llms.txt", "/llms-full.txt", "/manifest.webmanifest"];
export const NOIMOS_SITEMAP_PREFIXES: string[] = [];
