import { SiteLink } from "@/components/SiteChrome";
import { BUSINESS } from "@/lib/business";

// Branded 404 in the site's language (ja). Uses the active design tokens
// (bg-background / text-foreground / text-muted / bg-primary — globals.css).
// The home link is a <SiteLink>: on a path mount it points at the customer's
// own root instead of a "/" this artifact does not serve (src/lib/siteNav.ts).
export default function NotFound() {
  return (
    <main className="flex min-h-[70vh] flex-col items-center justify-center gap-7 px-6 py-20 text-center">
      <p className="font-heading text-6xl font-extrabold tracking-tight text-primary">404</p>
      <div className="space-y-3">
        <h1 className="font-heading text-2xl font-bold text-foreground">ページが見つかりません</h1>
        <p className="max-w-md text-sm leading-[1.9] text-muted">
          お探しのページは、移動または削除された可能性があります。URLをご確認いただくか、トップページからお進みください。
        </p>
      </div>
      <div className="flex flex-col items-center gap-3 sm:flex-row">
        <SiteLink
          href="/"
          className="rounded-md bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-soft transition-colors hover:bg-deep"
        >
          トップページへ戻る
        </SiteLink>
        <a
          href={BUSINESS.telHref}
          className="rounded-md border border-primary/25 bg-primary-soft px-6 py-3 text-sm font-bold text-primary transition-colors hover:border-primary/50"
        >
          お電話でのご相談 {BUSINESS.tel}
        </a>
      </div>
      <p className="text-xs text-muted">
        {BUSINESS.storeName}（運営：{BUSINESS.company}）
      </p>
    </main>
  );
}
