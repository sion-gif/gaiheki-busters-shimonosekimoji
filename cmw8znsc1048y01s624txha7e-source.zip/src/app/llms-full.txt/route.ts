import { SITE_NAME, SITE_DESCRIPTION } from "@/lib/site";
import { fetchSiteBlogGroups } from "@/lib/articles";
import { discoveryPages, discoveryUrl, singleLine } from "@/lib/discovery";

/** Expanded page summaries and CMS excerpts, drawn from the same public records. */
export async function GET() {
  const groups = await fetchSiteBlogGroups();
  let body = `# ${singleLine(SITE_NAME)}\n\n> ${singleLine(SITE_DESCRIPTION)}\n\n## Pages\n`;
  const append = (section: string) => {
    if (body.length + section.length > 200_000) return false;
    body += section;
    return true;
  };
  const seen = new Set<string>();
  for (const page of discoveryPages()) {
    seen.add(page.url);
    const group = groups.find(group => discoveryUrl(group.basePath) === page.url);
    if (!append(`\n### ${singleLine(page.title ?? group?.name ?? (page.route === "/" ? "Home" : page.route))}\n${page.url}\n${singleLine(page.description ?? group?.description ?? (page.route === "/" ? SITE_DESCRIPTION : ""))}\n`)) break;
  }
  for (const group of groups) for (const article of group.articles) {
    const url = discoveryUrl(article.link);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    if (!append(`\n### ${singleLine(article.title)}\n${url}\n${singleLine(article.excerpt ?? "")}\n`)) break;
  }
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
}
