import { getSitemapEntries } from "@/lib/sitemap-data";
import { singleSitemap } from "@/lib/sitemaps";

// Read the CMS when the sitemap is requested, never during `next build`: an
// incomplete read refuses to answer, and at build time that would block publishing.
export const dynamic = "force-dynamic";

/** The build manifest owns static public pages; the CMS owns published articles. */
export default async function sitemap() {
  return singleSitemap(await getSitemapEntries());
}
