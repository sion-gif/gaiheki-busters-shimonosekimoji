import { SITE_NAME, SITE_DESCRIPTION } from "@/lib/site";
import { fetchSiteBlogGroups } from "@/lib/articles";
import { discoveryPages, discoveryUrl, linkTitle, singleLine, markdownUrl } from "@/lib/discovery";

const LIMIT = 10_000;

/** A bounded index of the same public pages as the sitemap; articles remain CMS-scoped. */
export async function GET() {
  const groups = await fetchSiteBlogGroups();
  const pages = discoveryPages();
  let body = `# ${singleLine(SITE_NAME)}\n\n> ${singleLine(SITE_DESCRIPTION).slice(0, 500)}\n\n## Core Pages\n`;
  const seen = new Set<string>();
  // Reserve room for every blog destination before listing individual articles.
  for (const page of pages) {
    const group = groups.find(group => discoveryUrl(group.basePath) === page.url);
    const title = linkTitle(page.title ?? group?.name ?? (page.route === "/" ? "Home" : page.route));
    const description = singleLine(page.description ?? group?.description ?? (page.route === "/" ? SITE_DESCRIPTION : "")).slice(0, 500);
    const line = `- [${title}](${markdownUrl(page.url)})${description ? ": " + description : ""}\n`;
    if (body.length + line.length > 6_000) break;
    body += line;
    seen.add(page.url);
  }
  body += "\n## Optional\n";
  for (const group of groups) {
    const url = discoveryUrl(group.basePath);
    if (!url || !group.articles.length || seen.has(url)) continue;
    const line = `- [${linkTitle(group.name)}](${markdownUrl(url)}): ${singleLine(group.description ?? "Articles and updates").slice(0, 500)}\n`;
    if (body.length + line.length > LIMIT) break;
    body += line;
    seen.add(url);
  }
  for (const article of groups.flatMap(group => group.articles)) {
    const url = discoveryUrl(article.link);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    const line = `- [${linkTitle(article.title)}](${markdownUrl(url)})\n`;
    if (body.length + line.length > LIMIT) break;
    body += line;
  }
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
}
