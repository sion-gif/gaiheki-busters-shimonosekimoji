import type { Metadata } from "next";
import { BUSINESS } from "@/lib/business";

export const metadata: Metadata = {
  title: "プライバシーポリシー",
  description:
    "ガイヘキ洗浄バスターズ 下関門司店（関門WORKS.）における個人情報の取り扱いについてご案内します。",
  alternates: { canonical: "./" },
};

export default function PrivacyPage() {
  return (
    <main className="bg-background">
      <div className="border-b border-border/70 bg-surface/60">
        <div className="mx-auto w-full max-w-3xl px-5 py-12 sm:px-8 sm:py-16">
          <p className="font-heading text-[11px] font-bold tracking-[0.22em] text-primary">PRIVACY POLICY</p>
          <h1 className="mt-3 font-heading text-2xl font-bold tracking-tight text-foreground sm:text-3xl">プライバシーポリシー</h1>
          <p className="mt-4 text-sm leading-[1.9] text-muted">
            {BUSINESS.storeName}（運営：{BUSINESS.company}）は、お客様の個人情報を適切に取り扱うため、以下のとおり定めます。
          </p>
        </div>
      </div>

      <article className="mx-auto w-full max-w-3xl px-5 py-12 sm:px-8 sm:py-16">
        <div className="space-y-10 text-sm leading-[1.95] text-foreground">
          <section>
            <h2 className="font-heading text-lg font-bold">1. 取得する情報</h2>
            <p className="mt-3 text-muted">
              お問い合わせフォームやお電話などを通じて、お名前、フリガナ、電話番号、メールアドレス、ご住所、ご相談内容、および外壁の写真などを取得する場合があります。
            </p>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">2. 利用目的</h2>
            <ul className="mt-3 list-disc space-y-1.5 pl-5 text-muted">
              <li>お問い合わせ・ご相談への回答、お見積りのご連絡</li>
              <li>現地確認や洗浄日程の調整、施工に関するご連絡</li>
              <li>アフターサポートのご案内</li>
              <li>上記に付随する事務連絡</li>
            </ul>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">3. 第三者への提供</h2>
            <p className="mt-3 text-muted">
              法令に基づく場合を除き、ご本人の同意なく個人情報を第三者へ提供することはありません。
            </p>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">4. 業務の委託</h2>
            <p className="mt-3 text-muted">
              業務の一部を委託する場合には、委託先に対して必要かつ適切な監督を行います。
            </p>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">5. 安全管理</h2>
            <p className="mt-3 text-muted">
              取得した個人情報の漏えい、紛失、改ざんなどを防ぐため、必要かつ適切な安全管理措置を講じます。
            </p>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">6. 開示・訂正・削除</h2>
            <p className="mt-3 text-muted">
              ご本人からの個人情報の開示・訂正・削除などのご希望は、下記の連絡先までご連絡ください。ご本人であることを確認したうえで、法令に従い対応します。
            </p>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">7. アクセス解析について</h2>
            <p className="mt-3 text-muted">
              当サイトでは、利用状況を把握し、内容を改善するために、個人を特定しない形のアクセス解析を利用しています。
            </p>
          </section>

          <section>
            <h2 className="font-heading text-lg font-bold">8. 本方針の見直し</h2>
            <p className="mt-3 text-muted">
              本方針は、必要に応じて見直すことがあります。変更後の内容は当ページに掲載します。
            </p>
          </section>

          <section className="rounded-lg border border-border bg-surface/60 p-6">
            <h2 className="font-heading text-lg font-bold">お問い合わせ窓口</h2>
            <dl className="mt-4 space-y-2 text-muted">
              <div>
                <dt className="text-xs font-semibold text-foreground">事業者</dt>
                <dd>{BUSINESS.company}（{BUSINESS.storeName}）</dd>
              </div>
              <div>
                <dt className="text-xs font-semibold text-foreground">所在地</dt>
                <dd>{BUSINESS.address}</dd>
              </div>
              <div>
                <dt className="text-xs font-semibold text-foreground">電話番号</dt>
                <dd>
                  <a href={BUSINESS.telHref} className="text-primary underline underline-offset-2">
                    {BUSINESS.tel}
                  </a>
                  （電話受付 {BUSINESS.telHours}／{BUSINESS.closed}）
                </dd>
              </div>
            </dl>
          </section>
        </div>
      </article>
    </main>
  );
}
