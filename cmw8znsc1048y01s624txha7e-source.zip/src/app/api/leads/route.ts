import { NextResponse } from "next/server";
import { z } from "zod";
import { db, NoDatabaseError } from "@/lib/db";
import { sendOwnerNotification, sendVisitorAutoresponder } from "@/lib/email";
import { forwardLeadToCrm } from "@/lib/crm";
import { BUSINESS } from "@/lib/business";

const leadSchema = z.object({
  name: z.string().max(100).optional(),
  kana: z.string().max(100).optional(),
  tel: z.string().max(30).optional(),
  email: z.string().email().max(320),
  address: z.string().max(300).optional(),
  message: z.string().max(5000).optional(),
  source: z.string().max(500).optional(),
  // Honeypot — real visitors leave this empty.
  hp: z.string().optional(),
});

export async function POST(request: Request) {
  const parsed = leadSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Invalid input" }, { status: 400 });
  }

  // Bot caught by the honeypot — answer as success, store nothing.
  if (parsed.data.hp) return NextResponse.json({ ok: true });

  const { name, kana, tel, email, address, message, source } = parsed.data;

  try {
    await db.execute({
      sql: "INSERT INTO leads (name, kana, email, tel, address, message, source) VALUES (?, ?, ?, ?, ?, ?, ?)",
      args: [name ?? null, kana ?? null, email, tel ?? null, address ?? null, message ?? null, source ?? null],
    });
  } catch (error) {
    if (error instanceof NoDatabaseError) {
      return NextResponse.json({ ok: false, error: "Storage not ready" }, { status: 503 });
    }
    console.error("lead insert failed", error);
    return NextResponse.json({ ok: false, error: "Could not save" }, { status: 500 });
  }

  // Email is best-effort: it is a silent no-op until email is enabled in Manage.
  // The DB insert above is the source of truth, so a mail failure must never fail capture.
  try {
    const lines = [
      `お名前: ${name ?? "（未記入）"}${kana ? `（${kana}）` : ""}`,
      `電話番号: ${tel ?? "（未記入）"}`,
      `メール: ${email}`,
      address ? `ご住所: ${address}` : null,
      message ? `\nご相談内容:\n${message}` : null,
      source ? `\n送信ページ: ${source}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    await sendOwnerNotification({
      subject: `【${BUSINESS.storeName}】お問い合わせが届きました`,
      html: `<pre style="font-family:system-ui,sans-serif;font-size:14px;line-height:1.8">${lines}</pre>`,
      replyTo: email,
    });

    await sendVisitorAutoresponder(email, {
      subject: `【${BUSINESS.storeName}】お問い合わせを受け付けました`,
      html: `<p>${name ? `${name} 様` : "お客様"}</p><p>お問い合わせありがとうございます。内容を確認のうえ、担当（${BUSINESS.company}）よりご連絡します。</p><p>お急ぎの場合は ${BUSINESS.tel}（電話受付 ${BUSINESS.telHours}／${BUSINESS.closed}）へお電話ください。</p><p>${BUSINESS.storeName}<br>${BUSINESS.address}</p>`,
    });
  } catch {
    // Never let email break lead capture.
  }

  // Mirror into the workspace CRM when the owner turned CRM lead sync on.
  await forwardLeadToCrm({ name, kana, tel, email, address, message, source }, request.headers.get("origin"));

  return NextResponse.json({ ok: true });
}
