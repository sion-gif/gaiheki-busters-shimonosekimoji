import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  CloudRain,
  Clock,
  Droplets,
  Leaf,
  MapPin,
  FileText,
  Paintbrush,
  Phone,
  Ruler,
  ShieldCheck,
  Sparkles,
  Waves,
} from "lucide-react";
import ContactForm from "@/components/ContactForm";
import FaqAccordion, { type FaqItem } from "@/components/FaqAccordion";
import { BUSINESS, IMAGES } from "@/lib/business";
import { SITE_URL } from "@/lib/site";

const container = "mx-auto w-full max-w-6xl px-5 sm:px-8";
const sectionBase = "scroll-mt-24 border-t border-border/70 py-16 sm:py-24";
const eyebrowClass = "font-heading text-[11px] font-bold tracking-[0.22em] text-primary";

const worries = [
  {
    icon: Droplets,
    title: "黒ずみが広がってきた",
    body: "排気口のまわりや、手の届かない高い場所。全体にうっすら広がる黒ずみも、洗浄で落とせます。",
  },
  {
    icon: Leaf,
    title: "北側の壁にコケ・カビ・藻",
    body: "日当たりの悪い北側は、コケや藻が育ちやすい場所。放置すると外壁に水分が残り続けます。",
  },
  {
    icon: CloudRain,
    title: "雨だれの筋が目立つ",
    body: "雨水の流れに沿って汚れが引っかかり、縦じまになって残ります。窓まわりや隅の汚れも一緒に。",
  },
  {
    icon: Paintbrush,
    title: "塗装するほどでもない気がする",
    body: "まだ塗り替えが必要かどうか、判断がむずかしい。まずは外壁の状態を見せてください。",
  },
];

const aboutPoints = [
  {
    icon: Droplets,
    question: "外壁洗浄って、何をするの？",
    answer:
      "専用の洗浄液で、外壁についた汚れだけを落とします。外壁を削ったり、塗り替えたりする作業ではありません。",
  },
  {
    icon: ShieldCheck,
    question: "何のためにするの？",
    answer:
      "汚れを落とすと、外壁に残っていた水分やコケがなくなります。外壁を傷める原因が、ひとつ減るイメージです。",
  },
  {
    icon: Sparkles,
    question: "何がいいの？",
    answer:
      "足場を組まないので、費用も日数も抑えられます。まだ塗り替えが必要でない外壁なら、洗うだけで戻ります。",
  },
];

const reasons = [
  {
    number: "01",
    icon: Ruler,
    title: "足場を組まずに洗浄します",
    body:
      "最大約8.9mまで伸びる専用のポールブラシを使い、一般的な戸建て住宅は3階建てまで地上から洗浄します。音も少なく、ご近所にも配慮した施工です。",
  },
  {
    number: "02",
    icon: Droplets,
    title: "素材と汚れに合わせた洗浄液とソフトブラシ",
    body:
      "外壁の素材や汚れの種類に合わせて、洗浄液と洗浄方法を選びます。飛び散りが少なく、低臭・環境配慮型の洗浄液を使用します。",
  },
  {
    number: "03",
    icon: ShieldCheck,
    title: "洗浄が適さないときは、正直にお伝えします",
    body:
      "汚れだけでなく、ひび割れや塗膜の劣化も確認します。洗浄が適さない場合は無理に施工せず、状態に合ったメンテナンスをご案内します。",
  },
  {
    number: "04",
    icon: Building2,
    title: "外壁洗浄専門ブランドの下関門司店",
    body:
      "ガイヘキ洗浄バスターズは全国150店舗以上の外壁洗浄専門ブランド。下関市・門司区は関門WORKS.が担当します。",
  },
];

const priceExamples = [
  { label: "外壁1面 約40㎡", value: "41,180円（税込）〜", note: "980円 × 40㎡ ＋ 基本料金1,980円" },
  { label: "30㎡（外壁1面）", value: "29,400円", note: "980円 × 30㎡（別途 基本料金1,980円）" },
  { label: "120㎡（外壁全面）", value: "117,600円", note: "980円 × 120㎡（別途 基本料金1,980円）" },
];

const options = [
  { label: "カーポート・テラス屋根", price: "660円/㎡〜" },
  { label: "玄関・アプローチタイル", price: "660円/㎡〜" },
  { label: "バルコニー床", price: "550円/㎡〜" },
  { label: "コンクリート土間", price: "660円/㎡〜" },
  { label: "塀", price: "660円/㎡〜" },
];

const flowSteps = [
  {
    step: "STEP 1",
    title: "お問い合わせ",
    body:
      "お電話かフォームでお気軽にご相談ください。フォームからの場合は、洗浄したい箇所がわかる写真を添えると、より正確なお見積りができます。",
  },
  {
    step: "STEP 2",
    title: "現地確認・お見積り・ご契約",
    body:
      "担当スタッフが現地で採寸と汚れの状況を確認し、その場でお見積りをご提示します。ご納得いただければ、洗浄日程を決めます。内容によっては当日対応も可能です。",
  },
  {
    step: "STEP 3",
    title: "現地にて洗浄",
    body:
      "専用ポールブラシで、足場を組まない外壁洗浄を行います。飛び散りが少なく、低臭・環境配慮型の洗浄液を使用します。",
  },
  {
    step: "STEP 4",
    title: "お支払い",
    body: "洗浄完了当日、または後日お送りする請求書にて、期限内にお願いしています。",
  },
  {
    step: "STEP 5",
    title: "アフターサポート",
    body: "洗浄後に気になる箇所や、その他の汚れがありましたら、お気軽にお問い合わせください。",
  },
];

const compareRows = [
  { label: "目的", coating: "建物の保護機能の回復・強化、美観の刷新", washing: "美観の回復（汚れ除去）、清潔さの維持" },
  { label: "工期", coating: "長い（約7日〜2週間）", washing: "短い（数時間〜2日）" },
  { label: "費用", coating: "高額（数百万円程度）", washing: "安価（数万円程度）" },
  { label: "足場", coating: "必要", washing: "不要" },
];

const faqItems: FaqItem[] = [
  {
    question: "外壁洗浄と外壁塗装は、何が違いますか？",
    answer:
      "外壁塗装は、建物の保護機能の回復・強化と美観の刷新が目的で、工期は約7日〜2週間、費用は数百万円程度、足場が必要です。外壁洗浄は、美観の回復（汚れ除去）と清潔さの維持が目的で、工期は数時間〜2日、費用は数万円程度、足場は不要です。汚れだけが気になっている場合は、洗浄という選択肢があります。",
  },
  {
    question: "足場は本当に不要ですか？",
    answer:
      "一般的な戸建て住宅では、原則として足場を設置せず、最大約8.9mまで伸びる専用ポールブラシで地上から洗浄します（3階建てまで対応）。建物の形状や周囲の状況によっては、事前の確認が必要です。現地確認のうえご案内します。",
  },
  {
    question: "洗浄だけでは落ちない汚れはありますか？",
    answer:
      "はい。黒ずみ・コケ・藻・雨だれなどの汚れは洗浄で落とせますが、ひび割れや塗膜の劣化は洗っても戻りません。外壁の状態を確認し、洗浄が適さない場合は無理に施工せず、状態に合ったメンテナンスをご案内します。",
  },
  {
    question: "見積りは無料ですか？",
    answer:
      "無料です。現地で採寸と汚れの状況を確認し、その場でお見積りします。写真や図面からのお見積りにも対応しています。無料テスト洗浄も実施していますので、仕上がりを確かめてからご検討いただけます。",
  },
  {
    question: "お支払いのタイミングは？",
    answer: "洗浄完了当日、または後日お送りする請求書にて、期限内にお願いしています。",
  },
  {
    question: "対応エリアはどこですか？",
    answer: `山口県下関市、福岡県北九州市門司区です。${BUSINESS.storeName}が担当します。`,
  },
  {
    question: "洗浄液は安心して使えますか？",
    answer:
      "飛び散りが少なく、低臭・環境配慮型の洗浄液を使用しています。外壁の素材や汚れに合わせて、洗浄液と洗浄方法を選びます。",
  },
];

const businessJsonLd = {
  "@context": "https://schema.org",
  "@type": "HomeAndConstructionBusiness",
  "@id": `${SITE_URL}/#store`,
  name: BUSINESS.storeName,
  description:
    "山口県下関市・福岡県北九州市門司区の外壁洗浄。足場を組まず、専用の洗浄液とソフトブラシで外壁の汚れを落とします。",
  url: `${SITE_URL}/`,
  image: IMAGES.hero,
  telephone: "+81-80-2938-2832",
  address: {
    "@type": "PostalAddress",
    addressRegion: "山口県",
    addressLocality: "下関市",
    streetAddress: "彦島江の浦町9-8-22",
    addressCountry: "JP",
  },
  areaServed: BUSINESS.area.map((name) => ({ "@type": "AdministrativeArea", name })),
  parentOrganization: { "@type": "Organization", name: BUSINESS.parentCompany },
  sameAs: [BUSINESS.instagram, BUSINESS.tiktok, BUSINESS.storePage],
  openingHoursSpecification: {
    "@type": "OpeningHoursSpecification",
    dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    opens: "08:00",
    closes: "19:00",
  },
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqItems.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: { "@type": "Answer", text: item.answer },
  })),
};

function SectionHeading({
  eyebrow,
  title,
  lead,
  align = "left",
}: {
  eyebrow: string;
  title: string;
  lead?: string;
  align?: "left" | "center";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <p className={eyebrowClass}>{eyebrow}</p>
      <h2 className="mt-3 font-heading text-[26px] font-bold leading-[1.35] tracking-tight text-foreground sm:text-[34px]">{title}</h2>
      {lead && <p className="mt-4 text-[15px] leading-[1.9] text-muted">{lead}</p>}
    </div>
  );
}

export default function Home() {
  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(businessJsonLd).replace(/</g, "\\u003c") }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd).replace(/</g, "\\u003c") }}
      />

      {/* ============ Hero ============ */}
      <section id="top" className="relative overflow-hidden bg-gradient-to-b from-surface via-surface/60 to-background">
        <div className={`${container} grid items-center gap-10 pb-14 pt-10 sm:pb-20 sm:pt-16 lg:grid-cols-[1.02fr_1fr] lg:gap-14`}>
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-background px-3.5 py-1.5 text-xs font-semibold text-primary">
              <MapPin aria-hidden className="h-3.5 w-3.5" />
              {BUSINESS.area[0]}・{BUSINESS.area[1]}
            </p>
            <h1 className="mt-5 font-heading text-[32px] font-extrabold leading-[1.28] tracking-tight text-foreground sm:text-[46px] lg:text-[52px]">
              外壁を洗う、
              <br />
              という選択肢。
            </h1>
            <p className="mt-5 max-w-xl text-[15px] leading-[1.95] text-muted sm:text-base">
              {BUSINESS.storeName}は、足場を組まずに外壁の汚れを落とす外壁洗浄の専門店です。外壁の素材や汚れに合わせた専用の洗浄液とソフトブラシで、汚れだけを洗い流します。
            </p>
            <p className="mt-3 max-w-xl text-[15px] leading-[1.95] text-muted">
              洗浄が適さない状態のときは、無理に施工せず、状態に合ったメンテナンスをご案内します。
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <a
                href={BUSINESS.telHref}
                className="group flex items-center justify-center gap-3 rounded-md bg-primary px-6 py-4 text-primary-foreground shadow-lift transition-colors hover:bg-deep"
              >
                <Phone aria-hidden className="h-5 w-5" />
                <span className="text-left leading-tight">
                  <span className="block text-[11px] font-medium opacity-85">電話で無料相談（{BUSINESS.telHours}）</span>
                  <span className="block font-heading text-lg font-bold tracking-wide tabular-nums">{BUSINESS.tel}</span>
                </span>
              </a>
              <a
                href="#contact"
                className="flex items-center justify-center gap-2 rounded-md border border-primary/25 bg-background px-6 py-4 font-semibold text-primary transition-colors hover:border-primary/50 hover:bg-primary-soft"
              >
                <FileText aria-hidden className="h-5 w-5" />
                フォームで無料見積り
              </a>
            </div>

            <dl className="mt-9 grid grid-cols-3 gap-3 border-t border-primary/15 pt-6">
              {[
                { term: "足場", desc: "不要" },
                { term: "料金", desc: "1㎡ 980円〜" },
                { term: "店舗数", desc: "全国150店舗以上" },
              ].map((item) => (
                <div key={item.term}>
                  <dt className="text-[11px] font-medium text-muted">{item.term}</dt>
                  <dd className="mt-1 font-heading text-[15px] font-bold text-foreground sm:text-base">{item.desc}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative">
            <figure className="m-0">
              <div className="relative aspect-[4/3] overflow-hidden rounded-lg bg-surface shadow-lift">
                <Image
                  src={IMAGES.hero}
                  alt="専用ポールブラシで住宅の外壁を洗浄する職人の作業風景"
                  fill
                  priority
                  sizes="(min-width: 1024px) 46vw, 100vw"
                  className="object-cover"
                />
                <span className="absolute bottom-3 left-3 rounded-full bg-deep px-3 py-1 text-[10px] font-semibold tracking-wide text-white">
                  実際の施工の様子
                </span>
              </div>
            </figure>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-md border border-border bg-background px-4 py-3 shadow-soft">
                <p className="flex items-center gap-2 font-heading text-sm font-bold text-foreground">
                  <CheckCircle2 aria-hidden className="h-4 w-4 text-primary" />
                  無料テスト洗浄を実施中
                </p>
                <p className="mt-1 text-xs leading-relaxed text-muted">一部分で仕上がりを確かめてからご検討いただけます。</p>
              </div>
              <div className="rounded-md border border-border bg-background px-4 py-3 shadow-soft">
                <p className="flex items-center gap-2 font-heading text-sm font-bold text-foreground">
                  <CheckCircle2 aria-hidden className="h-4 w-4 text-primary" />
                  写真・図面からのお見積り
                </p>
                <p className="mt-1 text-xs leading-relaxed text-muted">現地に行く前に、おおよその金額をお伝えできます。</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ お悩み ============ */}
      <section id="worry" className={sectionBase}>
        <div className={container}>
          <SectionHeading
            eyebrow="PROBLEM"
            title="外壁の汚れ、こんなふうに気になっていませんか"
            lead="帰ってきて、ふと壁を見る。少し前より、汚れが目につくようになった。そんな変化から始まることが多いようです。"
          />
          <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {worries.map((item) => (
              <li key={item.title} className="rounded-lg border border-border bg-card p-6 shadow-soft">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary-soft text-primary">
                  <item.icon aria-hidden className="h-5 w-5" />
                </span>
                <h3 className="mt-4 font-heading text-base font-bold leading-snug text-foreground">{item.title}</h3>
                <p className="mt-2 text-[13px] leading-[1.85] text-muted">{item.body}</p>
              </li>
            ))}
          </ul>

          <div className="mt-8 grid gap-4 rounded-lg border border-primary/15 bg-primary-soft/50 p-6 sm:grid-cols-[1fr_auto] sm:items-center sm:p-8">
            <p className="text-[15px] leading-[1.9] text-foreground">
              汚れは、洗えば落とせます。劣化は、洗っても戻りません。
              <span className="block text-sm text-muted">まずは外壁の状態を見せてください。洗うべきか、塗るべきかを含めてご案内します。</span>
            </p>
            <a
              href={BUSINESS.telHref}
              className="inline-flex items-center justify-center gap-2 rounded-md bg-background px-5 py-3 text-sm font-bold text-primary shadow-soft transition-colors hover:bg-background/80"
            >
              <Phone aria-hidden className="h-4 w-4" />
              {BUSINESS.tel}
            </a>
          </div>
        </div>
      </section>

      {/* ============ 外壁洗浄とは ============ */}
      <section id="about" className={`${sectionBase} bg-surface/60`}>
        <div className={container}>
          <SectionHeading
            eyebrow="ABOUT"
            title="外壁洗浄とは、何をするもの？"
            lead="外壁をきれいにするだけではなく、住まいを長く保つための選択肢のひとつです。3つの質問から、かんたんに説明します。"
          />
          <div className="mt-10 grid gap-5 lg:grid-cols-3">
            {aboutPoints.map((point) => (
              <div key={point.question} className="rounded-lg border border-border bg-background p-6 shadow-soft sm:p-7">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <point.icon aria-hidden className="h-5 w-5" />
                </span>
                <h3 className="mt-4 font-heading text-base font-bold text-foreground">{point.question}</h3>
                <p className="mt-2 text-sm leading-[1.9] text-muted">{point.answer}</p>
              </div>
            ))}
          </div>

          <div className="mt-10 grid items-center gap-8 lg:grid-cols-[1fr_1fr] lg:gap-12">
            <div>
              <h3 className="font-heading text-lg font-bold text-foreground sm:text-xl">汚れと、劣化はちがいます</h3>
              <p className="mt-3 text-sm leading-[1.95] text-muted">
                外壁の黒ずみ・コケ・藻・雨だれは「汚れ」です。洗浄で落とせます。一方で、ひび割れや塗膜の劣化は「劣化」で、洗っても元には戻りません。その場合は補修や塗装が必要になります。
              </p>
              <p className="mt-3 text-sm leading-[1.95] text-muted">
                だからこそ、洗う前に外壁の状態を確認します。汚れだけなら洗浄を。劣化が見られるなら、その状態に合ったメンテナンスを。どちらが適しているかを含めて、正直にお伝えします。
              </p>
              <figure className="mt-6">
                <div className="overflow-hidden rounded-lg shadow-soft">
                  <Image
                    src={IMAGES.beforeAfter}
                    alt="外壁洗浄のビフォーアフター。左が洗浄前の汚れた外壁、右が洗浄後のきれいな外壁"
                    width={780}
                    height={625}
                    sizes="(min-width: 1024px) 45vw, 100vw"
                    className="h-auto w-full object-cover"
                  />
                </div>
                <figcaption className="mt-2 text-[11px] text-muted">
                  左：洗浄前／右：洗浄後（実際の施工写真）
                </figcaption>
              </figure>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 sm:gap-5">
              <figure>
                <div className="overflow-hidden rounded-lg shadow-soft">
                  <Image
                    src={IMAGES.moss}
                    alt="北側の外壁に広がったコケや黒ずみの汚れ"
                    width={2048}
                    height={1536}
                    sizes="(min-width: 1024px) 22vw, 45vw"
                    className="h-auto w-full object-cover"
                  />
                </div>
                <figcaption className="mt-2 text-[11px] text-muted">コケ・黒ずみの例（イメージ）</figcaption>
              </figure>
              <figure className="sm:mt-8">
                <div className="overflow-hidden rounded-lg shadow-soft">
                  <Image
                    src={IMAGES.brush}
                    alt="ソフトブラシと洗浄液で外壁の汚れを落とす手元"
                    width={2048}
                    height={1536}
                    sizes="(min-width: 1024px) 22vw, 45vw"
                    className="h-auto w-full object-cover"
                  />
                </div>
                <figcaption className="mt-2 text-[11px] text-muted">専用洗浄液とソフトブラシ（イメージ）</figcaption>
              </figure>
              <p className="rounded-md bg-background p-4 text-xs leading-[1.8] text-muted sm:col-span-2">
                黒ずみ・コケ・藻・雨だれは、外壁の表面についた汚れです。洗浄液となじませ、ソフトブラシで洗い流します。外壁を削ったり、塗り替えたりはしません。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ============ 選ばれる理由 ============ */}
      <section id="reason" className={sectionBase}>
        <div className={container}>
          <SectionHeading
            eyebrow="REASON"
            title="ガイヘキ洗浄バスターズ 下関門司店が選ばれる理由"
            lead="外壁洗浄の専門ブランドだから、汚れだけでなく外壁の状態も見ます。"
          />
          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {reasons.map((item) => (
              <div key={item.number} className="relative rounded-lg border border-border bg-card p-6 shadow-soft sm:p-8">
                <span aria-hidden className="absolute right-6 top-5 font-heading text-3xl font-extrabold text-primary/10">
                  {item.number}
                </span>
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary-soft text-primary">
                  <item.icon aria-hidden className="h-5 w-5" />
                </span>
                <h3 className="mt-4 font-heading text-base font-bold leading-snug text-foreground sm:text-lg">{item.title}</h3>
                <p className="mt-2 text-[13px] leading-[1.9] text-muted sm:text-sm">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ 料金 ============ */}
      <section id="price" className={`${sectionBase} bg-surface/60`}>
        <div className={container}>
          <SectionHeading
            eyebrow="PRICE"
            title="洗浄面積に応じた、わかりやすい料金"
            lead="汚れが気になったときに、気軽にご利用いただける料金体系です。見積りは無料。実際の金額は現地確認のうえご案内します。"
          />

          <div className="mt-10 grid gap-6 lg:grid-cols-[1.1fr_1fr]">
            <div className="rounded-lg border border-primary/20 bg-background p-7 shadow-lift sm:p-9">
              <p className="text-sm font-semibold text-muted">外壁洗浄</p>
              <p className="mt-2 flex flex-wrap items-baseline gap-2">
                <span className="font-heading text-lg font-bold text-foreground">1㎡あたり</span>
                <span className="font-heading text-[42px] font-extrabold leading-none tracking-tight text-primary tabular-nums">980</span>
                <span className="font-heading text-base font-bold text-foreground">円（税込）〜</span>
              </p>
              <p className="mt-3 inline-flex items-baseline gap-2 rounded-md bg-primary-soft px-4 py-2 text-sm font-semibold text-primary">
                ＋ 基本料金 1,980円（税込）
              </p>
              <p className="mt-5 text-sm leading-[1.9] text-muted">
                1㎡あたりの料金 × 洗浄面積 ＋ 基本料金 が、お支払い金額の目安です。
              </p>
              <ul className="mt-6 space-y-3 border-t border-border pt-6">
                {priceExamples.map((example) => (
                  <li key={example.label} className="flex items-start justify-between gap-4">
                    <span className="text-[13px] font-medium text-muted">
                      {example.label}
                      <span className="mt-0.5 block text-[11px] text-muted/80">{example.note}</span>
                    </span>
                    <span className="shrink-0 font-heading text-base font-bold text-foreground tabular-nums">{example.value}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg border border-border bg-background p-7 shadow-soft sm:p-9">
              <h3 className="font-heading text-base font-bold text-foreground">外壁とあわせて、こんな場所も洗浄できます</h3>
              <p className="mt-2 text-[13px] leading-[1.85] text-muted">外壁洗浄にプラスして、外壁以外のスペースも専用ブラシで丁寧に洗浄します。</p>
              <dl className="mt-5 divide-y divide-border">
                {options.map((option) => (
                  <div key={option.label} className="flex items-center justify-between py-3">
                    <dt className="text-sm text-foreground">{option.label}</dt>
                    <dd className="font-heading text-sm font-bold text-primary tabular-nums">{option.price}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-5 rounded-md bg-surface px-4 py-3 text-xs leading-relaxed text-muted">
                記載の金額は税込・一例です。汚れの状態や面積により変わりますので、まずはお見積りをご依頼ください。
              </p>
            </div>
          </div>

          <div className="mt-8 flex flex-col items-start justify-between gap-4 rounded-lg border border-accent/25 bg-background p-6 sm:flex-row sm:items-center sm:p-7">
            <div>
              <p className="font-heading text-base font-bold text-foreground">無料テスト洗浄を実施しています</p>
              <p className="mt-1 text-sm text-muted">まずは一部分で、仕上がりをお確かめください。実際の汚れ落ちを見てからご検討いただけます。</p>
            </div>
            <Link
              href="#contact"
              className="inline-flex shrink-0 items-center gap-2 rounded-md bg-accent-strong px-5 py-3 text-sm font-bold text-accent-foreground shadow-soft transition-opacity hover:opacity-90"
            >
              無料見積りを依頼する
              <ArrowRight aria-hidden className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ============ 施工の流れ ============ */}
      <section id="flow" className={sectionBase}>
        <div className={container}>
          <SectionHeading
            eyebrow="FLOW"
            title="ご相談から洗浄までの流れ"
            lead="お問い合わせから仕上がりまで、5つのステップです。わからないことは、その都度ご確認ください。"
          />
          <ol className="mt-10 space-y-4">
            {flowSteps.map((item) => (
              <li key={item.step} className="grid gap-4 rounded-lg border border-border bg-card p-6 shadow-soft sm:grid-cols-[9rem_1fr] sm:p-7">
                <div>
                  <p className={eyebrowClass}>{item.step}</p>
                  <h3 className="mt-1 font-heading text-base font-bold text-foreground sm:text-lg">{item.title}</h3>
                </div>
                <p className="text-[13px] leading-[1.95] text-muted sm:text-sm">{item.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ============ 洗浄と塗装 ============ */}
      <section id="compare" className={`${sectionBase} bg-surface/60`}>
        <div className={container}>
          <SectionHeading
            eyebrow="COMPARE"
            title="洗浄と塗装は、役割がちがいます"
            lead="どちらが良い・悪いではなく、外壁の状態と目的で選ぶものです。違いを整理しました。"
          />
          <div className="mt-10 overflow-hidden rounded-lg border border-border bg-background shadow-soft">
            <table className="w-full border-collapse text-left text-sm">
              <caption className="sr-only">外壁塗装と外壁洗浄の比較</caption>
              <thead>
                <tr className="bg-surface">
                  <th scope="col" className="w-[22%] px-4 py-4 text-[12px] font-semibold text-muted sm:px-6">項目</th>
                  <th scope="col" className="px-4 py-4 font-heading text-[13px] font-bold text-foreground sm:px-6 sm:text-sm">外壁塗装</th>
                  <th scope="col" className="px-4 py-4 font-heading text-[13px] font-bold text-primary sm:px-6 sm:text-sm">外壁洗浄</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {compareRows.map((row) => (
                  <tr key={row.label} className="align-top">
                    <th scope="row" className="px-4 py-4 text-[12px] font-semibold text-muted sm:px-6">{row.label}</th>
                    <td className="px-4 py-4 text-[13px] leading-relaxed text-muted sm:px-6">{row.coating}</td>
                    <td className="bg-primary-soft/40 px-4 py-4 text-[13px] font-medium leading-relaxed text-foreground sm:px-6">{row.washing}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            <div className="rounded-lg border border-border bg-background p-6 shadow-soft">
              <p className="text-[11px] font-semibold text-muted">例① 外壁塗装</p>
              <p className="mt-2 font-heading text-2xl font-extrabold text-foreground tabular-nums">約200万円前後</p>
              <p className="mt-2 text-xs leading-relaxed text-muted"></p>
            </div>
            <div className="rounded-lg border border-primary/25 bg-background p-6 shadow-soft">
              <p className="text-[11px] font-semibold text-primary">例② 外壁洗浄</p>
              <p className="mt-2 font-heading text-2xl font-extrabold text-primary tabular-nums">約4万円〜20万円</p>
              <p className="mt-2 text-xs leading-relaxed text-muted"></p>
            </div>
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-muted">
            ※生涯費用は当社顧客アンケート調べ（2024年9月〜2025年8月実施）に基づく一例で、約245万円の差になります。店舗数は当社調べ（2025年8月時点／外壁洗浄専門業者における店舗数比較）。建物の状態やご希望により金額は変わります。
          </p>
        </div>
      </section>

      {/* ============ 対応エリア・店舗 ============ */}
      <section id="shop" className={sectionBase}>
        <div className={container}>
          <SectionHeading
            eyebrow="AREA & SHOP"
            title="対応エリアと店舗情報"
            lead={`${BUSINESS.area[0]}・${BUSINESS.area[1]}の外壁洗浄は、${BUSINESS.storeName}にご相談ください。`}
          />
          <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.05fr]">
            <div className="overflow-hidden rounded-lg border border-border bg-card shadow-soft">
              <Image
                src={IMAGES.town}
                alt="下関市・門司区の住宅街の風景"
                width={2048}
                height={1360}
                sizes="(min-width: 1024px) 48vw, 100vw"
                className="h-auto w-full object-cover"
              />
              <div className="p-6 sm:p-7">
                <h3 className="flex items-center gap-2 font-heading text-base font-bold text-foreground">
                  <MapPin aria-hidden className="h-4 w-4 text-primary" />
                  対応エリア
                </h3>
                <ul className="mt-3 flex flex-wrap gap-2">
                  {BUSINESS.area.map((area) => (
                    <li key={area} className="rounded-full border border-primary/20 bg-primary-soft/60 px-3.5 py-1.5 text-[13px] font-semibold text-primary">
                      {area}
                    </li>
                  ))}
                </ul>
                <p className="mt-4 text-[13px] leading-[1.85] text-muted">
                  上記エリアの戸建て住宅・店舗の外壁洗浄を承っています。アパートなどの集合住宅にも対応しています。
                </p>
              </div>
            </div>

            <div className="rounded-lg border border-border bg-background p-6 shadow-lift sm:p-8">
              <h3 className="font-heading text-lg font-bold text-foreground">{BUSINESS.storeName}</h3>
              <dl className="mt-5 divide-y divide-border text-sm">
                {[
                  { label: "運営", value: BUSINESS.company },
                  { label: "所在地", value: BUSINESS.address },
                  { label: "電話番号", value: BUSINESS.tel },
                  { label: "電話受付", value: BUSINESS.telHours },
                  { label: "営業時間", value: BUSINESS.hours },
                  { label: "定休日", value: BUSINESS.closed },
                  { label: "対応エリア", value: BUSINESS.area.join("、") },
                ].map((row) => (
                  <div key={row.label} className="grid grid-cols-[5.5rem_1fr] gap-3 py-3">
                    <dt className="text-[12px] font-semibold text-muted">{row.label}</dt>
                    <dd className="text-[13px] leading-relaxed text-foreground">{row.value}</dd>
                  </div>
                ))}
              </dl>

              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                <a
                  href={BUSINESS.telHref}
                  className="flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-3.5 text-sm font-bold text-primary-foreground transition-colors hover:bg-deep"
                >
                  <Phone aria-hidden className="h-4 w-4" />
                  電話で相談する
                </a>
                <a
                  href="#contact"
                  className="flex items-center justify-center gap-2 rounded-md border border-primary/25 bg-primary-soft px-4 py-3.5 text-sm font-bold text-primary transition-colors hover:border-primary/50"
                >
                  <FileText aria-hidden className="h-4 w-4" />
                  フォームで相談する
                </a>
              </div>

              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted">
                <span className="inline-flex items-center gap-1.5">
                  <Clock aria-hidden className="h-3.5 w-3.5" />
                  {BUSINESS.closed}
                </span>
                <a href={BUSINESS.storePage} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2 hover:text-primary">
                  ブランドサイトの店舗ページ
                </a>
                <a href={BUSINESS.instagram} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2 hover:text-primary">
                  Instagram
                </a>
                <a href={BUSINESS.tiktok} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2 hover:text-primary">
                  TikTok
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ よくある質問 ============ */}
      <section id="faq" className={`${sectionBase} bg-surface/60`}>
        <div className={container}>
          <SectionHeading
            eyebrow="FAQ"
            title="よくある質問"
            lead="ご相談の前に、よくいただく質問をまとめました。ここにないことは、お気軽にお問い合わせください。"
          />
          <div className="mt-10">
            <FaqAccordion items={faqItems} />
          </div>
        </div>
      </section>

      {/* ============ お問い合わせ ============ */}
      <section id="contact" className={sectionBase}>
        <div className={container}>
          <SectionHeading
            eyebrow="CONTACT"
            title="まずは、外壁の状態をお聞かせください"
            lead="ご相談・お見積りは無料です。写真や図面からでもお見積りできます。お電話、またはフォームからどうぞ。"
          />
          <div className="mt-10 grid gap-6 lg:grid-cols-[0.85fr_1.15fr] lg:gap-8">
            <div className="space-y-4">
              <a
                href={BUSINESS.telHref}
                className="block rounded-lg border border-primary/20 bg-primary-soft/60 p-6 transition-colors hover:border-primary/40"
              >
                <span className="flex items-center gap-2 text-[11px] font-bold tracking-[0.16em] text-primary">
                  <Phone aria-hidden className="h-4 w-4" />
                  TELEPHONE
                </span>
                <span className="mt-2 block font-heading text-2xl font-extrabold tracking-tight text-foreground tabular-nums">
                  {BUSINESS.tel}
                </span>
                <span className="mt-1 block text-xs text-muted">電話受付 {BUSINESS.telHours}／{BUSINESS.closed}</span>
              </a>
              <div className="rounded-lg border border-border bg-surface/70 p-6">
                <p className="font-heading text-sm font-bold text-foreground">お見積りの前に、わかる範囲で</p>
                <ul className="mt-3 space-y-2 text-[13px] leading-relaxed text-muted">
                  {["建物の種類（戸建て・店舗など）とおおよその築年数", "気になる場所（北側の壁、雨だれ、カーポートなど）", "外壁の写真や図面（お見積りの際にご確認させてください）"].map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <CheckCircle2 aria-hidden className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="rounded-lg border border-border bg-background p-6 shadow-lift sm:p-8">
              <h3 className="flex items-center gap-2 font-heading text-lg font-bold text-foreground">
                <Waves aria-hidden className="h-5 w-5 text-primary" />
                フォームで無料見積り
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-muted">
                必須項目を入力して送信してください。内容を確認のうえ、担当（{BUSINESS.company}）よりご連絡します。
              </p>
              <div className="mt-6">
                <ContactForm />
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
